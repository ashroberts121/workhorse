<?php 
    $active = 'cvjob';
    include('head.php');
    include('nav.php');
?>

<div class="container-flex">

    <!--Intro Section-->
    <div class="col-md-8 offset-md-2 cvInfo">
        <h1>CV and Career Packages</h1>
        <p>
            Struggling to create a CV that makes you stand out? <br>
            At Workhorse we don't just stop there, from CV Writing, LinkedIn 
            Profiles to Professional Career Coaching, we do the work for you! <br>
            Let us know how we can help by contacting <a href="mailto:info@helloworkhorse.com?subject=Package Purchasing Help">info@helloworkhorse.com</a> or 
            simply select your package below! 
        </p>
    </div>

    <hr class="infoHR">

    <div class="col-md-10 offset-md-1 cvPacks">
        <div class="row">
            <div class="col-12 col-md-10 offset-md-1">
                <a href="mailto:info@helloworkhorse.com?subject=Platinum Package Purchase"><img src="img/platinum.jpg"></a>
            </div>
        </div>
    </div>

    <div class="col-md-10 offset-md-1 cvPacks">
        <div class="row">
            <div class="col-12 col-md-10 offset-md-1">
                <a href="mailto:info@helloworkhorse.com?subject=Gold Package Purchase"><img src="img/gold.jpg"></a>
            </div>
        </div>
    </div>

    <div class="col-md-10 offset-md-1 cvPacks">
        <div class="row">
            <div class="col-12 col-md-10 offset-md-1">
                <a href="mailto:info@helloworkhorse.com?subject=Silver Package Purchase"><img src="img/silver.jpg"></a>
            </div>
        </div>
    </div>

    <div class="col-md-10 offset-md-1 cvPacks">
        <div class="row">
            <div class="col-12 col-md-10 offset-md-1">
                <a href="mailto:info@helloworkhorse.com?subject=Career Coaching Purchase"><img src="img/career_coaching.jpg"></a>
            </div>
        </div>
    </div>

    <div class="col-md-10 offset-md-1 cvPacks">
        <div class="row">
            <div class="col-12 col-md-10 offset-md-1">
                <a href="mailto:info@helloworkhorse.com?subject=Cover Letter Purchase"><img src="img/cover_letter.jpg"></a>
            </div>
        </div>
    </div>

</div><!--container-flex-->

<?php include('footer.php'); ?>