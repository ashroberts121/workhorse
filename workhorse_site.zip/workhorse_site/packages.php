<?php 
    $active = 'packages';
    include('head.php');
    include('nav.php');
?>

<div class="container-flex">

    <!--Intro Section-->
    <div class="col-md-8 offset-md-2 packInfo">
        <h1>Career Support</h1>
        <p class="mb-2">
            Here at Workhorse we understand that searching for a new job 
            whether it’s climbing the career ladder or looking for your next 
            break can be challenging but you are not on your own! 
        </p>
        <p>
            Take a look at our FREE downloadable materials to give you that extra support. 
            Looking for more support then contact us to find out how we can help. 
        </p>
    </div>

    <hr class="packHR">

    <!--Intro Section-->
    <div class="col-md-8 offset-md-2 packInfo packQuestion">
        <p>
            Is it time to look for a new job?
        </p>
        <p>
            Make use of our Weeky Planner to keep on track <a href="Workhorse Weekly Planner.pdf">here</a>!
        </p>
        <hr class="packHR">
        <p>
            Can’t decide what you are looking for? 
        </p>
        <p>
            Take our ‘This or That’ <a href="Workhorse Dream Job- This or That Quiz.pdf">Quiz</a> to find out.
        </p>
        <hr class="packHR">
        <p>
            Download our FREE <a href="Workhorse Job Application Tracker.pdf">Job Application Tracker</a> to stay ahead of the game!
        </p>
    </div>

    <!--CV Upload Section-->
    <div class="col-md-6 offset-md-3 homeInfo">
        <a href="mailto:info@helloworkhorse.com?subject=Free CV Review (Attached)"><img src="img/freecvreview.jpg" width="100%" height="auto"></div></a>
    </div>

</div><!--container-flex-->

<?php include('footer.php'); ?>