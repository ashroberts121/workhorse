<?php 
    $active = 'employers';
    include('head.php');
    include('nav.php');
?>

<div class="container-flex">

    <!--Intro Section-->
    <div class="col-md-8 offset-md-2 employersInfo">
        <h1>Recruitment Services</h1>
        <p class="mb-4">
        Supporting internal recruitment teams & hiring managers to attract & retain excellent employees. 
        </p>
        <img src="img/workhorse_placements.jpg"> 
    </div>

    <hr class="employersHR">

    <!--Intro Section-->
    <div class="col-md-8 offset-md-2 employersInfo employersQuestion">
        <p>
            <span class="my-1">Looking for great candidates but not
            the agency fee?</span><br>
            Sign up to our candidate referral service and have
            access to our best candidates for a small referral fee!
        </p>
        <hr class="employersHR">
        <p>
            Email <a href="mailto:stephanie@helloworkhorse.com">stephanie@helloworkhorse.com</a>
            for more information and a free quote.
        </p>
    </div>

</div><!--container-flex-->

<?php include('footer.php'); ?>