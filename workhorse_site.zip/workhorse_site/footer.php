<footer class="footer">
    <div class="container-flex">
        <span>
            <a href="helloworkhorse.com_privacypolicy.pdf">Privacy Policy</a> | <a href="#">Terms & Conditions</a>
        </span>
        <br>
        <p>
            <i>Workhorse is a trading name of helloworkhorse.com Ltd.</i>
        </p>
    </div>
</footer>

</body>
</html>