<header class="whNav" role="banner">
    <a href="index.php"><img id="logo-main" src="img/workhorse_logo.jpg" alt="WorkHorse Logo"></a>
    <hr class="navHR">
    <ul class="nav justify-content-center">
        <li class="nav-item">
            <a class="nav-link <?php if($active == 'about'){echo 'active';};?>" href="about.php">ABOUT</a>
            <span class="sr-only"><?php if($active == 'home'){echo '(current)';};?></span>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php if($active == 'cvjob'){echo 'active';};?>" href="cvjob.php">CV & CAREER PACKAGES
            <span class="sr-only"><?php if($active == 'home'){echo '(current)';};?></span>
            </a>
            
        </li>
        <li class="nav-item">
            <a class="nav-link <?php if($active == 'packages'){echo 'active';};?>" href="packages.php">CAREER SUPPORT</a>
            <span class="sr-only"><?php if($active == 'home'){echo '(current)';};?></span>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php if($active == 'employers'){echo 'active';};?>" href="employers.php" tabindex="-1" aria-disabled="true">WORKHORSE PLACEMENTS</a>
            <span class="sr-only"><?php if($active == 'home'){echo '(current)';};?></span>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php if($active == 'contact'){echo 'active';};?>" href="contact.php" tabindex="-1" aria-disabled="true">CONTACT</a>
            <span class="sr-only"><?php if($active == 'home'){echo '(current)';};?></span>
        </li>
    </ul>
    <hr class="navHR">
</header>