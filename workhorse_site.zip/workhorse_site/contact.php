<?php 
    $active = 'contact';
    include('head.php');
    include('nav.php');
?>

<div class="container-flex">

    <!--Intro Section-->
    <section class="mb-4 mx-5 contactInfo">

    <!--Section heading-->
    <h2 class="h1-responsive my-4">Contact Us</h2>
    <!--Section description-->
    <p class="text-center w-responsive mx-auto mb-5">
    Contact us today & let us do the work for you!
    <br>
    Our team will respond within 2 hours to all enquiries, we look forward to hearing from you. 
    </p>

    <div class="row">
        <!--Grid column-->
        <div class="col-md-8 offset-md-2">
            <div class="row">
                <div class="col-md-4">
                    <i class="fa fa-instagram fa-2x"></i>
                    <a href="http://"><p>@helloworkhorse</p></a>
                </div>
                <div class="col-md-4"> 
                    <i class="fa fa-facebook fa-2x"></i>
                    <a href="http://"><p>/helloworkhorse</p></a>
                </div> 
                <div class="col-md-4">
                    <i class="fas fa-envelope fa-2x"></i>
                    <a href="mailto:stephanie@helloworkhorse.com"><p>stephanie@helloworkhorse.com</p></a>
                </div>
            </div>
        </div>
        <!--Grid column-->
    </div>
    <div class="col">
        <img src="img/contact_quote.jpg" width="50%">
    </div>

</section>

</div><!--container-flex-->

<?php include('footer.php'); ?>