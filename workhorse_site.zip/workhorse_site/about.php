<?php 
    $active = 'about';
    include('head.php');
    include('nav.php');
?>

<div class="container-flex">

    <!--Intro Section-->
    <div class="col-md-8 offset-md-2 infoInfo">
        <h1>About Us!</h1>

        <img src="img/about_me.jpg"/>
        <p>
            Hello Workhorses! My name is Stephanie Ashfield, I am the founder of Workhorse Career and
            Recruitment Consultancy (helloworkhorse.com Ltd).
        </p>
        <hr class="infoHR">
        <p>
            I founded Workhorse in early 2021 after seeing so many talented candidates out of work due to the
            pandemic. After 7 years of recruitment experience, I naturally started helping my friends and family
            to get back on their feet which led to being recommended to a wide range of candidates in need of
            support.
        </p>
        <br>
        <p>
            My areas of expertise are Recruiting, CV writing, Career Coaching, HR and Employment Law. My
            biggest passion is preparing candidates for interviews and coaching them to career success.
        </p>
        <br>
        <p>
            The recruitment industry has changed so rapidly over the last 18 months which has led to more
            career changes than normal. Afterall, how did we know that so many industries would shut down,
            make redundancies, and close their doors.
        </p>
        <br>
        <p>
            So, with an army of Workhorses ready to take their careers to the next level I cannot wait to find you
            all your dream jobs!
            </p>
    </div>

    <hr class="infoHR">
    
    <!-- 'testimonials noted off'
    <hr class="infoHR">

    <div class="col-md-8 offset-md-2 infoTests">
        <div class="row">
            <h2 class="col">Testimonials</h2>
            <div class="col-12">
                <img src="img/avatar.png"/>
            </div>
            <div class="col-8 offset-2">
                <h5>Lorem Ipsum</h5>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor 
                    incididunt ut labore et dolore magna aliqua.
                </p>
            </div>
            <div class="col-12">
                <img src="img/avatar.png"/>
            </div>
            <div class="col-8 offset-2">
                <h5>Lorem Ipsum</h5>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor 
                    incididunt ut labore et dolore magna aliqua.
                </p>
            </div>
        </div>
    </div>
    -->

</div><!--container-flex-->

<?php include('footer.php'); ?>