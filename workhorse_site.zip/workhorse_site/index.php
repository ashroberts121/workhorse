<?php 
    include('head.php');
    include('nav.php');
?>

<div class="container-flex">

    <!--Intro Section-->
    <div class="col-md-8 offset-md-2 homeInfo">
        <h1>Hello Workhorses!</h1>
        <p>
            Workhorse are a one-stop service delivering all your career & recruitment support needs, founded by a fellow workhorse
            with bags of experience so you have come to the right place.
        </p>
        <br>
        <p>
            Struggling to create a CV that makes you stand out? <br>
            At Workhorse we don't just stop there, from CV Writing, LinkedIn
            Profiles to Professional Career Coaching, we do the work for you! <br> 
        </p>
        <br>
        <p>
            Let us know how we can help by contacting
            <a href='mailto:info@helloworkhorse.com?subject=General Enquiry'>info@helloworkhorse.com</a>
        </p>
    </div>

    
    <!--Video Section-->
    <!--video noted off
    <div class="col-10 offset-1 col-lg-6 offset-lg-3 homeVid">
    <video style="box-shadow: 5px 5px 20px grey;" width="100%" height="auto" controls>
        <source src="vid/placeholder.mp4" type="video/mp4">
        </video>
    </div>
    -->

    <!--How it Works Section-->
    <div class="col-md-8 offset-md-2 homeHow">
        <h3>How It Works</h3>    
        <div class="col-12 homeSteps">
            <div class="col-10 offset-1 col-md-8 offset-md-2 stepsBox">
                <h5>STEP 1</h5>
                <p>
                    SELECT YOUR <a href="#">PACKAGE</a>
                </p>
            </div>
            <div class="col-10 offset-1 col-md-8 offset-md-2 stepsBox">
                <h5>STEP 2</h5>
                <p>
                    CLICK 'PURCHASE' AND FOLLOW THE STEPS
                </p>
            </div>
            <div class="col-10 offset-1 col-md-8 offset-md-2 stepsBox">
                <h5>STEP 3</h5>
                <p>
                    FOLLOW THE INSTRUCTIONS IN YOUR WELCOME EMAIL, MAKE SURE TO HAVE
                    YOUR CURRENT CV OR EXPERIENCE TO HAND
                </p>
            </div>
            <div class="col-10 offset-1 col-md-8 offset-md-2 stepsBox">
                <h5>STEP 4</h5>
                <p>
                    LET US DO THE WORK FOR YOU! IN THE MEANTIME, START LOOKING
                    FOR YOUR DREAM JOB AND YOUR WORK WILL BE DONE WITHIN 48 HOURS
                </p>
            </div>
        </div>
    </div>

    <!--CV Upload Section-->
    <div class="col-md-6 offset-md-3 homeInfo">
        <a href="mailto:info@helloworkhorse.com?subject=Free CV Review (Attached)"><img src="img/freecvreview.jpg" width="100%" height="auto"></div></a>
    </div>

</div><!--container-flex-->

<?php include('footer.php'); ?>